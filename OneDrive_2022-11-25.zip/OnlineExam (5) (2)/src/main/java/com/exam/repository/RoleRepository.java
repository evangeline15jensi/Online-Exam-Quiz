package com.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.modal.Role;
import com.exam.modal.User;

public interface RoleRepository extends JpaRepository<Role, Long> {

	

}
